# import numpy as np
# import pandas as pd
# import pickle
# from sklearn.preprocessing import OneHotEncoder, StandardScaler
# from sklearn.pipeline import Pipeline
# from sklearn.ensemble import RandomForestClassifier
# from sklearn.compose import ColumnTransformer
# from sklearn.model_selection import train_test_split

# data = pd.read_csv('C:/Users/saksh/OneDrive/Desktop/final/MRCDOSAGE.csv')
# data.columns = data.columns.str.strip().str.lower()

# required_columns = {'symptom', 'age', 'temperature', 'gender', 'medicine', 'dosage per day', 'doctor name', 'doctor contact', 'location'}
# if not required_columns.issubset(set(data.columns)):
#     raise KeyError(f"Missing required columns. Available columns: {list(data.columns)}")

# X = data[['symptom', 'age', 'temperature', 'gender']]
# y = data[['medicine', 'dosage per day', 'doctor name', 'doctor contact', 'location']]

# y = y.astype(str)

# column_transformer = ColumnTransformer([
#     ('encoder', OneHotEncoder(handle_unknown='ignore'), ['symptom', 'gender']),
#     ('scaler', StandardScaler(), ['age', 'temperature'])
# ], remainder='passthrough')

# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# pipeline = Pipeline([
#     ('preprocessor', column_transformer),
#     ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
# ])

# pipeline.fit(X_train, y_train)

# with open('C:/Users/saksh/OneDrive/Desktop/final/medicine_model.pkl', 'wb') as f:
#     pickle.dump(pipeline, f)

# print("Model trained and saved successfully!")

# with open('C:/Users/saksh/OneDrive/Desktop/final/medicine_model.pkl', 'rb') as f:
#     medicine_model = pickle.load(f)

# sample_input = pd.DataFrame([['Cough', 30, 98.6, 'Male']], columns=['symptom', 'age', 'temperature', 'gender'])
# prediction = medicine_model.predict(sample_input)[0]

# print("\nPredicted Output:")
# print(f"Medicine: {prediction[0]}")
# print(f"Dosage: {prediction[1]}")
# print(f"Doctor: {prediction[2]}")
# print(f"Contact: {prediction[3]}")
# print(f"Location: {prediction[4]}")



# #cholestrol training
# #train_cholestrol_model.py

# import pandas as pd
# import pickle
# from sklearn.model_selection import train_test_split
# from sklearn.preprocessing import OneHotEncoder
# from sklearn.ensemble import RandomForestRegressor
# from sklearn.pipeline import Pipeline
# from sklearn.compose import ColumnTransformer
# from sklearn.metrics import mean_absolute_error, r2_score

# # Load dataset
# df = pd.read_csv("cholestrol.csv")

# # Define features and target
# X = df.drop(columns=["New Dosage (mg/dL)"])
# y = df["New Dosage (mg/dL)"]

# # Preprocessing
# categorical_cols = ["Weight", "Liver Function", "LDL Levels (mg/dL)"]
# preprocessor = ColumnTransformer(transformers=[
#     ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols)
# ], remainder='passthrough')

# # Model pipeline
# pipeline = Pipeline(steps=[
#     ('preprocessor', preprocessor),
#     ('regressor', RandomForestRegressor(n_estimators=100, random_state=42))
# ])

# # Split
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Train
# pipeline.fit(X_train, y_train)

# # Predict on test set
# y_pred = pipeline.predict(X_test)

# # Evaluation
# r2 = r2_score(y_test, y_pred)
# mae = mean_absolute_error(y_test, y_pred)
# accuracy = 100 - (mae / y_test.mean() * 100)

# print(f"R² Score: {r2:.2f}")
# print(f"Mean Absolute Error: {mae:.2f}")
# print(f"Custom Accuracy: {accuracy:.2f}%")

# # Save model
# with open("cholestrol_model.pkl", "wb") as f:
#     pickle.dump(pipeline, f)

# print("Model trained and saved as cholestrol_model.pkl")




## bp training 

# import pandas as pd
# from sklearn.model_selection import train_test_split
# from sklearn.ensemble import RandomForestClassifier
# from sklearn.metrics import accuracy_score
# import pickle

# # Load dataset
# df = pd.read_csv("bp.csv")

# # Features and target
# X = df.iloc[:, :5]
# y = df["New Dosage (mg/day)"]

# # Train-test split
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Train classifier
# model = RandomForestClassifier(n_estimators=100, random_state=42)
# model.fit(X_train, y_train)

# # Predict and evaluate
# y_pred = model.predict(X_test)
# accuracy = accuracy_score(y_test, y_pred)
# print(f"Accuracy: {accuracy * 100:.2f}%")

# # Save model
# with open("bp_model.pkl", "wb") as f:
#     pickle.dump(model, f)



# ## sugar training

# import pandas as pd
# import numpy as np
# from sklearn.model_selection import train_test_split
# from sklearn.ensemble import RandomForestRegressor
# from sklearn.metrics import r2_score
# import pickle

# # Load the dataset
# df = pd.read_csv("sugar.csv")

# # Rename columns to remove formatting issues (like special characters)
# df.columns = [
#     "Age",
#     "Current Dosage (mg)",
#     "Fasting Blood Glucose (mg/dL)",
#     "Postprandial Blood Glucose (mg/dL)",
#     "BMI (kg/m2)",
#     "Hemoglobin A1c (%)",
#     "New Dosage (mg)"
# ]

# # Separate features and target
# X = df.drop(columns=["New Dosage (mg)"])
# y = df["New Dosage (mg)"]

# # Split the dataset
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Train the model
# model = RandomForestRegressor(n_estimators=100, random_state=42)
# model.fit(X_train, y_train)

# # Evaluate the model
# y_pred = model.predict(X_test)
# r2 = r2_score(y_test, y_pred)
# print(f"Model R² Accuracy: {r2:.2f}")

# # Save the model
# with open("sugar_model.pkl", "wb") as f:
#     pickle.dump(model, f)
