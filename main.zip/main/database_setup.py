import sqlite3

# Connect to SQLite database (creates the file if it doesn’t exist)
conn = sqlite3.connect("database.db")
cursor = conn.cursor()

# Create table for storing medicine recommendations
cursor.execute("""
    CREATE TABLE IF NOT EXISTS medicine_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        symptoms TEXT,
        age INTEGER,
        temperature REAL,
        gender TEXT,
        medicine TEXT,
        dosage TEXT,
        doctor TEXT,
        contact TEXT,
        location TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
""")

conn.commit()
conn.close()
print("Database and table created successfully!")
