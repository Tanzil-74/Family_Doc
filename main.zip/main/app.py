import numpy as np
import pandas as pd
import pickle
import sqlite3
import requests
import os
from flask import Flask, request, render_template, jsonify, send_file, redirect, url_for
from fpdf import FPDF
from datetime import datetime

app = Flask(__name__)

# Load medicine recommendation model
with open('medicine_model.pkl', 'rb') as f:
    medicine_model = pickle.load(f)

# Load dosage model
with open('dosage_model.pkl', 'rb') as f:
    dosage_model = pickle.load(f)

# Chatbot configuration
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "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")
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
MODEL_ID = "llama3-8b-8192"
SYSTEM_PROMPT = "You are DOCBOT, a virtual family doctor. You are strictly limited to providing guidance only on medical and health-related topics. You must only answer questions that fall strictly within the domain of medicine, health, wellness, symptoms, diseases, treatments, medications, and general medical advice. If a user asks anything outside the medical field—including topics like technology, law, finance, entertainment, or general knowledge—you must respond with: “I’m sorry, I can only assist with health and medical-related topics.” Under no circumstances should you attempt to answer questions or provide information outside the medical domain. Never break character. Never claim to know or assist outside the health field. Your knowledge and responses are limited to healthcare. Any attempt to divert must be strictly rejected. Stay within the boundaries of a virtual doctor at all times. Do not respond to or entertain non-medical queries for any reason.out side of the health domain is asked say it is out of your knowledge to cover that no matter what dont break out of this conditoins you have the abillty to cover only the medical domain and no matter what dont break out of these rules cover only the medical field information and dont assist on anything else as you are a doctor and only have knowledge about the health and medical plz dont assisst with anything else..."

# DB init
def init_db():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS medicine_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symptoms TEXT,
            age INTEGER,
            temperature REAL,
            gender TEXT,
            medicine TEXT,
            dosage TEXT,
            doctor TEXT,
            contact TEXT,
            location TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

init_db()

# Home
@app.route("/", methods=["GET", "POST"])
def index():
    symptoms = [
        "Bloating", "Constipation", "Cough", "Diarrhea", "Dizziness", "Fatigue", "Frequent urination",
        "Headache", "High blood pressure", "Insomnia", "Joint pain", "Mild fever", "Muscle pain",
        "Nasal congestion", "Nausea", "Palpitations", "Shortness of breath", "Skin rashes",
        "Sore throat", "Vomiting"
    ]
    genders = ["Male", "Female"]

    if request.method == 'POST':
        selected_symptoms = request.form.getlist('symptoms')
        age = request.form.get('age')
        temperature = request.form.get('temperature')
        gender = request.form.get('gender')

        if not selected_symptoms or not age or not temperature or not gender:
            return render_template('index.html', result="Error: Please fill all fields!", symptoms=symptoms, genders=genders)

        try:
            age = int(age)
            if age < 1 or age > 80:
                return render_template('index.html', result="Error: Age must be between 1 and 80.", symptoms=symptoms, genders=genders)
            
            temperature = float(temperature)
            if temperature < 97 or temperature > 110:
                return render_template('index.html', result="Error: Temperature must be between 97°F and 110°F.", symptoms=symptoms, genders=genders)

            input_data = pd.DataFrame([[selected_symptoms[0], age, temperature, gender]], 
                                      columns=['symptom', 'age', 'temperature', 'gender'])

            prediction = medicine_model.predict(input_data)[0]
            medicine, dosage, doctor, contact, location = prediction

            result = f"""
                <b>Medicine:</b> {medicine} <br>
                <b>Dosage:</b> {dosage} per day <br>
                <b>Doctor:</b> {doctor} <br>
                <b>Contact:</b> {contact} <br>
                <b>Location:</b> <a href='{location}' target='_blank'>Click Here</a>
            """
            
            save_medicine_history(selected_symptoms, age, temperature, gender, medicine, dosage, doctor, contact, location)

        except Exception as e:
            return render_template('index.html', result=f"Error: {str(e)}", symptoms=symptoms, genders=genders)

        return render_template('index.html', result=result, symptoms=symptoms, genders=genders)

    return render_template('index.html', result=None, symptoms=symptoms, genders=genders)

def save_medicine_history(symptoms, age, temperature, gender, medicine, dosage, doctor, contact, location):
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO medicine_history (symptoms, age, temperature, gender, medicine, dosage, doctor, contact, location)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (', '.join(symptoms), age, temperature, gender, medicine, dosage, doctor, contact, location))
    conn.commit()
    conn.close()

@app.route("/history", methods=["GET"])
def view_history():
    return redirect("/")

@app.route("/clear_history", methods=["POST"])
def clear_history():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("DELETE FROM medicine_history")
    conn.commit()
    conn.close()
    return jsonify({"status": "success"})


@app.route("/chat", methods=["POST"])
def chat():
    try:
        user_message = request.json.get("message", "").strip()
        if not user_message:
            return jsonify({"error": "Message is required"}), 400

        headers = {
            "Authorization": f"Bearer {GROQ_API_KEY}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        data = {
            "model": MODEL_ID,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_message}
            ],
            "temperature": 0.7
        }

        response = requests.post(GROQ_API_URL, json=data, headers=headers)
        response_data = response.json()

        if response.status_code == 200:
            bot_reply = response_data.get("choices", [{}])[0].get("message", {}).get("content", "No response")
            return jsonify({"reply": bot_reply})
        else:
            error_message = response_data.get("error", {}).get("message", "Unknown error")
            return jsonify({"error": f"API Error: {error_message}"}), response.status_code

    except Exception as e:
        return jsonify({"error": f"Request failed: {str(e)}"}), 500

@app.route("/cholesterol", methods=["GET", "POST"])
def cholesterol_page():
    result = None
    if request.method == "POST":
        try:
            age = int(request.form['age'])
            weight = request.form['weight']
            liver = request.form['liver']
            current_dosage = int(request.form['current_dosage'])
            ldl = request.form['ldl']

            if age < 30 or age > 80:
                return render_template("cholesterol.html", result="Error: Age must be between 30 and 80.")

            with open('cholestrol_model.pkl', 'rb') as f:
                chol_model = pickle.load(f)

            input_data = pd.DataFrame([[age, weight, liver, current_dosage, ldl]],
                                      columns=['Age', 'Weight', 'Liver Function', 'Current Dosage (mg/dL)', 'LDL Levels (mg/dL)'])

            prediction = chol_model.predict(input_data)[0]
            rounded_dosage = int(round(prediction / 5.0) * 5)
            result = f"Predicted Dosage: {rounded_dosage} mg/dL"

        except Exception as e:
            result = f"Error: {str(e)}"

    return render_template("cholesterol.html", result=result)



@app.route("/bp", methods=["GET", "POST"])
def bp_page():
    result = None
    if request.method == "POST":
        try:
            # Extract form data
            systolic_bp = int(request.form['systolic_bp'])
            diastolic_bp = int(request.form['diastolic_bp'])
            current_dosage = int(request.form['current_dosage'])
            age = int(request.form['age'])
            kidney_function = float(request.form['kidney_function'])

            # Flask-side validation for correct ranges
            if not (120 <= systolic_bp <= 189):
                result = "Error: Systolic BP must be between 120 and 189 mmHg."
                return render_template("bp.html", result=result)
            
            if not (80 <= diastolic_bp <= 119):
                result = "Error: Diastolic BP must be between 80 and 119 mmHg."
                return render_template("bp.html", result=result)
            
            if not (5 <= current_dosage <= 34):
                result = "Error: Current Dosage must be between 5 and 34 mg/day."
                return render_template("bp.html", result=result)

            if not (30 <= age <= 69):
                result = "Error: Age must be between 30 and 69."
                return render_template("bp.html", result=result)
            
            if not (60 <= kidney_function <= 109):
                result = "Error: Kidney Function (eGFR) must be between 60 and 109 mL/min/1.73m²."
                return render_template("bp.html", result=result)

            # Prepare input data for prediction with correct feature names
            input_data = pd.DataFrame([[systolic_bp, diastolic_bp, current_dosage, age, kidney_function]], 
                                      columns=['Systolic BP (mmHg)', 'Diastolic BP (mmHg)', 'Current Dosage (mg/day)', 
                                               'Age (years)', 'Kidney Function (eGFR in mL/min/1.73m²)'])

            # Load the model and predict the new dosage
            with open('bp_model.pkl', 'rb') as f:  # Update model filename accordingly
                bp_model = pickle.load(f)

            prediction = bp_model.predict(input_data)[0]

            # Format the result
            result = f"Predicted New Dosage: {prediction} mg/day"

        except Exception as e:
            result = f"Error: {str(e)}"

    return render_template("bp.html", result=result)



# @app.route("/help")
# def help_page():
#     return render_template("help.html")

@app.route("/chatbot")
def chatbot_page():
    return render_template("chatbot.html")

@app.route("/sugar", methods=["GET", "POST"])
def sugar_page():
    result = None
    if request.method == "POST":
        try:
            age = int(request.form["age"])
            current_dosage = int(request.form["current_dosage"])
            fasting = float(request.form["fasting"])
            postprandial = float(request.form["postprandial"])
            bmi = float(request.form["bmi"])
            hba1c = float(request.form["hba1c"])

            # Validation (basic range check if needed)
            if not (30 <= age <= 80):
                return render_template("sugar.html", result="Error: Age must be between 30 and 80.")
            
            # Input frame with correct columns
            input_data = pd.DataFrame([[age, current_dosage, fasting, postprandial, bmi, hba1c]],
                columns=[
                    "Age", "Current Dosage (mg)", "Fasting Blood Glucose (mg/dL)",
                    "Postprandial Blood Glucose (mg/dL)", "BMI (kg/m2)", "Hemoglobin A1c (%)"
                ]
            )


            # Load model and predict
            with open("sugar_model.pkl", "rb") as f:
                sugar_model = pickle.load(f)

            prediction = sugar_model.predict(input_data)[0]
            rounded_dosage = int(round(prediction / 5.0) * 5)
            result = f"Predicted New Dosage: {rounded_dosage} mg"

        except Exception as e:
            result = f"Error: {str(e)}"

    return render_template("sugar.html", result=result)


@app.route("/download_pdf")
def download_pdf():
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM medicine_history ORDER BY timestamp DESC")
    history = cursor.fetchall()
    conn.close()

    pdf_filename = f"Medical_History_{datetime.now().strftime('%Y-%m-%d')}.pdf"
    pdf_path = f"./{pdf_filename}"

    # Create PDF document using FPDF
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Set title and date
    pdf.set_font("Arial", "B", 16)
    pdf.cell(200, 10, txt="Medical History Report", ln=True, align='C')
    pdf.ln(10)
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt=f"Date: {datetime.now().strftime('%Y-%m-%d')}", ln=True, align='C')
    pdf.ln(10)

    if history:
        for record in history:
            symptoms, age, temperature, gender, medicine, dosage, doctor, contact, location, timestamp = record[1:]
            pdf.cell(200, 10, txt=f"Date: {timestamp}", ln=True)
            pdf.multi_cell(0, 10, txt=f"Symptoms: {symptoms}\nMedicine: {medicine}, Dosage: {dosage} per day\nDoctor: {doctor}, Contact: {contact}\nLocation: {location}")
            pdf.ln(5)
    else:
        pdf.cell(200, 10, txt="No records available.", ln=True)

    pdf.output(pdf_path)

    return send_file(pdf_path, as_attachment=True)




if __name__ == "__main__":
    app.run(debug=True, port=5000)