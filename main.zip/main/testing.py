# import pickle
# import pandas as pd

# # Load the trained model
# model_path = "C:/Users/saksh/OneDrive/Desktop/final - Copy/medicine_model.pkl"

# with open(model_path, 'rb') as f:
#     medicine_model = pickle.load(f)

# # Sample test cases
# test_data = pd.DataFrame([
#     ["Cough", 25, 99.5, "Male"],  # Case 1
#     ["Fatigue", 40, 98.7, "Female"],  # Case 2
#     ["Headache", 30, 100.1, "Male"],  # Case 3
#     ["Diarrhea", 22, 101.0, "Female"],  # Case 4
# ], columns=['symptom', 'age', 'temperature', 'gender'])

# # Run predictions
# predictions = medicine_model.predict(test_data)

# # Display results
# for i, pred in enumerate(predictions):
#     medicine, dosage, doctor, contact, location = pred
#     print(f"Test Case {i+1}:")
#     print(f"  Symptoms: {test_data.iloc[i, 0]}")
#     print(f"  Age: {test_data.iloc[i, 1]}")
#     print(f"  Temperature: {test_data.iloc[i, 2]}")
#     print(f"  Gender: {test_data.iloc[i, 3]}")
#     print(f"  → Recommended Medicine: {medicine}")
#     print(f"  → Dosage: {dosage} per day")
#     print(f"  → Doctor: {doctor}")
#     print(f"  → Contact: {contact}")
#     print(f"  → Location: {location}")
#     print("-" * 50)





#test_cholestrol_model.py

# import pandas as pd
# import pickle
# from sklearn.model_selection import train_test_split
# from sklearn.metrics import mean_absolute_error, r2_score
# import random

# # Load dataset
# df = pd.read_csv("cholestrol.csv")
# X = df.drop(columns=["New Dosage (mg/dL)"])
# y = df["New Dosage (mg/dL)"]

# # Train-test split
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Load trained model
# with open("cholestrol_model.pkl", "rb") as f:
#     model = pickle.load(f)

# # Predict on test set
# y_pred = model.predict(X_test)

# # Select 5 random indices from test set
# sample_indices = random.sample(range(len(X_test)), 5)

# print("=== 5 Random Test Predictions ===\n")
# for idx in sample_indices:
#     actual = y_test.iloc[idx]
#     predicted = round(y_pred[idx], 2)
#     print(f"Sample {idx + 1}: Actual = {actual} mg/dL, Predicted = {predicted} mg/dL")

# # Evaluation
# mae = mean_absolute_error(y_test, y_pred)
# r2 = r2_score(y_test, y_pred)
# accuracy = 100 - (mae / y_test.mean() * 100)

# print("\n=== Evaluation Metrics ===")
# print(f"R² Score: {r2:.2f}")
# print(f"Mean Absolute Error: {mae:.2f}")
# print(f"Custom Accuracy: {accuracy:.2f}%")



# ## bp testing

# import pandas as pd
# import numpy as np
# import pickle

# # Load the dataset (bp.csv)
# df = pd.read_csv('bp.csv')

# # Display the first 5 rows of the dataset to ensure it's loaded correctly
# print("First 5 rows of the dataset:")
# print(df.head())

# # Select the first 5 rows (if you want to use the first 5 data points for testing)
# test_data = df.head(5)

# # Separate the features and target (assuming the target column is named 'target')
# X_test = test_data.drop(columns=['target'])
# y_test = test_data['target']

# # Load the trained model from the pickle file
# with open('bp_model.pkl', 'rb') as file:
#     model = pickle.load(file)

# # Make predictions using the model
# predictions = model.predict(X_test)

# # Display the predictions
# print("\nPredictions for the first 5 rows:")
# for i, pred in enumerate(predictions):
#     print(f"Sample {i+1}: Predicted = {pred}, Actual = {y_test.iloc[i]}")

# # Optionally, calculate accuracy (if it's a classification task)
# accuracy = np.mean(predictions == y_test)
# print(f"\nAccuracy on the first 5 rows: {accuracy * 100:.2f}%")




##sugar testing code 

# import numpy as np
# import joblib

# # Load the trained model
# model = joblib.load("sugar_model.pkl")  # Ensure this file exists in your directory

# # Define 5 test cases: [Age, Current Dosage, Fasting BG, Postprandial BG, BMI, Hemoglobin A1c]
# test_cases = np.array([
#     [45, 12, 140, 210, 24.5, 7.1],  # Case 1
#     [60, 20, 110, 160, 30.0, 6.3],  # Case 2
#     [38, 10, 130, 190, 26.2, 6.8],  # Case 3
#     [55, 18, 150, 230, 28.5, 7.5],  # Case 4
#     [70, 25, 120, 170, 22.0, 6.1],  # Case 5
# ])

# # Make predictions
# predictions = model.predict(test_cases)

# # Display results
# for i, prediction in enumerate(predictions, start=1):
#     print(f"Condition {i} - Predicted New Dosage: {prediction:.2f} mg")
